package com.learning.core.day2.session1;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class D02P07 {
	public static List<String> findMatchingStrings(String[] dictionary, String pattern) {
        List<String> matchingStrings = new ArrayList<>();

        // Escape special characters in the pattern
        String escapedPattern = escapeSpecialChars(pattern);

        // Construct the regular expression pattern
        String regex = "^" + escapedPattern.replace("*", ".*") + "$";

        // Compile the regular expression pattern
        Pattern p = Pattern.compile(regex);

        // Iterate through the dictionary and match each string with the pattern
        for (String word : dictionary) {
            Matcher m = p.matcher(word);
            if (m.matches()) {
                matchingStrings.add(word);
            }
        }

        return matchingStrings;
    }

    // Method to escape special characters in the pattern
    private static String escapeSpecialChars(String pattern) {
        return pattern.replaceAll("[\\\\.+^$\\[\\](){}=!<>|:\\-]", "\\\\$0");
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] dictionary = {"abb", "abc", "xyz", "xyy","foo"};
        String pattern = "xy*";
        List<String> matchingStrings = findMatchingStrings(dictionary, pattern);
        
        System.out.println("Strings in the dictionary that match the pattern '" + pattern + "':");
        for (String match : matchingStrings) {
            System.out.println(match);
        }

	}

}
