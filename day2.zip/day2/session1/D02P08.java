package com.learning.core.day2.session1;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
public class D02P08 {
	 public static boolean canSplitIntoFour(String str) {
	        if (str.length() % 4 != 0) {
	            return false; // Length should be divisible by 4
	        }

	        Set<Character> uniqueChars = new HashSet<>();
	        for (char ch : str.toCharArray()) {
	            uniqueChars.add(ch);
	        }

	        return uniqueChars.size() == 4;
	    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();

        if (canSplitIntoFour(input)) {
            System.out.println("The given string can be split into four distinct strings.");
        } else {
            System.out.println("The given string cannot be split into four distinct strings.");
        }
        scanner.close();
	}

}
