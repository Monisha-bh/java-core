package com.learning.core.day2.session1;
import java.util.Scanner;
public class D02P02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);
        
        // Input string
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();
        
        // Input n
        System.out.print("Enter the value of n: ");
        int n = scanner.nextInt();
        
        // Count last 'n' vowels
        int vowelCount = countLastNVowels(inputString, n);
        
        // Output result
        if (vowelCount == -1) {
            System.out.println("Invalid input or no vowels found.");
        } else if (vowelCount < n) {
            System.out.println("Mismatch in vowel count input.");
        } else {
            System.out.println("Count of last " + n + " vowels: " + vowelCount);
        }
        
        scanner.close();
    }
    
    // Method to count last 'n' vowels
    public static int countLastNVowels(String str, int n) {
        int count = 0;
        int lastIndex = str.length() - 1;
        
        for (int i = lastIndex; i >= 0 && n > 0; i--) {
            char ch = Character.toLowerCase(str.charAt(i));
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
                n--;
            }
        }
        
        if (count == 0) { // No vowels found
            return -1;
        }
        
        return count;

	}

}
