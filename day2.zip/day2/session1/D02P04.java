package com.learning.core.day2.session1;

public class D02P04 {
	public static void main(String[] args) {
        String input = "aebcbda";
        int minDeletions = findMinDeletions(input);
        System.out.println("Minimum deletions needed to make the string palindrome: " + minDeletions);
    }

    public static int findMinDeletions(String input) {
        
        int[][] dp = new int[input.length()][input.length()];

        for (int i = input.length() - 1; i >= 0; i--) {
            for (int j = i + 1; j < input.length(); j++) {
                if (input.charAt(i) == input.charAt(j)) {
                    dp[i][j] = dp[i + 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(dp[i + 1][j], dp[i][j - 1]);
                }
            }
        }

        
        return dp[0][input.length() - 1];
    }

}
