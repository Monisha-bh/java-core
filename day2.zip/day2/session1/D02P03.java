package com.learning.core.day2.session1;
import java.util.ArrayList;
public class D02P03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input = "abc";
        ArrayList<String> subsequences = generateSubsequences(input);
        
        System.out.println("All subsequences of " + input + ": ");
        for (String subsequence : subsequences) {
            System.out.println(subsequence);
        }
    }

    public static ArrayList<String> generateSubsequences(String input) {
        ArrayList<String> subsequences = new ArrayList<>();
        generateSubsequencesHelper(input, 0, "", subsequences);
        return subsequences;
    }

    private static void generateSubsequencesHelper(String input, int index, String current, ArrayList<String> subsequences) {
        if (index == input.length()) {
            subsequences.add(current);
            return;
        }

       
        generateSubsequencesHelper(input, index + 1, current + input.charAt(index), subsequences);

        
        generateSubsequencesHelper(input, index + 1, current, subsequences);

	}

}
