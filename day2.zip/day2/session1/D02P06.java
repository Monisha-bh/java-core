package com.learning.core.day2.session1;

public class D02P06 {
	 public static int longestPrefixSuffixLength(String s) {
	        int n = s.length();
	        int[] lps = new int[n]; // Longest prefix suffix array

	        // Calculate the longest prefix suffix array using the KMP algorithm
	        computeLPSArray(s, lps);

	        // The length of the longest prefix suffix is the value at the last index of lps array
	        return lps[n - 1];
	    }

	    private static void computeLPSArray(String s, int[] lps) {
	        int len = 0; // Length of the previous longest prefix suffix
	        int i = 1;

	        while (i < s.length()) {
	            if (s.charAt(i) == s.charAt(len)) {
	                len++;
	                lps[i] = len;
	                i++;
	            } else {
	                if (len != 0) {
	                    len = lps[len - 1];
	                } else {
	                    lps[i] = 0;
	                    i++;
	                }
	            }
	        }
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "aabcdaabc";
        int longestLength = longestPrefixSuffixLength(s);
        System.out.println("Length of the longest prefix which is also a suffix: " + longestLength);
	}

}
