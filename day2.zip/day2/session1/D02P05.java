package com.learning.core.day2.session1;
import java.util.*;
public class D02P05 {
	public static boolean canFormCircle(String[] strings) {
        if (strings == null || strings.length == 0) {
            return false;
        }

        // Create a map to store the starting and ending characters of each string
        Map<Character, List<String>> map = new HashMap<>();
        for (String str : strings) {
            char firstChar = str.charAt(0);
            char lastChar = str.charAt(str.length() - 1);
            map.putIfAbsent(firstChar, new ArrayList<>());
            map.get(firstChar).add(str);
            map.putIfAbsent(lastChar, new ArrayList<>());
        }

        // Start DFS from the first character of the first string
        char startChar = strings[0].charAt(0);
        Set<String> visited = new HashSet<>();
        return dfs(map, startChar, startChar, visited, strings.length);
    }

    private static boolean dfs(Map<Character, List<String>> map, char startChar, char currentChar, Set<String> visited, int remaining) {
        if (remaining == 0) {
            // All strings are used, check if it forms a circle
            return currentChar == startChar;
        }

        if (!map.containsKey(currentChar)) {
            // No strings starting with the current character
            return false;
        }

        for (String str : map.get(currentChar)) {
            if (!visited.contains(str)) {
                visited.add(str);
                if (dfs(map, startChar, str.charAt(str.length() - 1), visited, remaining - 1)) {
                    return true;
                }
                visited.remove(str);
            }
        }

        return false;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] strings = {"abc", "efg", "cde", "ghi", "ija"};
        if (canFormCircle(strings)) {
            System.out.println("The strings can be chained to form a circle.");
        } else {
            System.out.println("The strings cannot be chained to form a circle.");
        }

	}

}
