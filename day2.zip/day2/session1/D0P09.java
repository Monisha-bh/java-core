package com.learning.core.day2.session1;
import java.util.Scanner;
public class D0P09 {
	public static String replaceSpaces(String str) {
        
        char[] charArray = str.toCharArray();
        
        
        int spaceCount = 0;
        for (char c : charArray) {
            if (c == ' ') {
                spaceCount++;
            }
        }
        
        
        int newLength = str.length() + spaceCount * 2;
        
        
        char[] newCharArray = new char[newLength];
        
       
        int index = 0;
        for (char c : charArray) {
            if (c == ' ') {
                newCharArray[index++] = '%';
                newCharArray[index++] = '2';
                newCharArray[index++] = '0';
            } else {
                newCharArray[index++] = c;
            }
        }
        
        return new String(newCharArray);
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();

        String replacedString = replaceSpaces(input);
        System.out.println("Replaced string: " + replacedString);
        scanner.close();
	}

}
