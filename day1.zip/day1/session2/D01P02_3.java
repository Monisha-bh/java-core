package com.learning.core.day1.session2;
import java.util.*;
public class D01P02_3 {
	 public static List<List<Integer>> findCombinations(int[] nums, int k) {
	        List<List<Integer>> result = new ArrayList<>();
	        List<Integer> combination = new ArrayList<>();
	        backtrack(nums, k, 0, combination, result);
	        return result;
	    }

	    private static void backtrack(int[] nums, int k, int start, List<Integer> combination, List<List<Integer>> result) {
	        if (combination.size() == k) {
	            result.add(new ArrayList<>(combination));
	            return;
	        }

	        for (int i = start; i < nums.length; i++) {
	            combination.add(nums[i]);
	            backtrack(nums, k, i + 1, combination, result);
	            combination.remove(combination.size() - 1);
	        }
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);
        
        // Input array
        System.out.println("Enter the numbers separated by spaces:");
        String[] input = scanner.nextLine().split(" ");
        int[] nums = new int[input.length];
        for (int i = 0; i < input.length; i++) {
            nums[i] = Integer.parseInt(input[i]);
        }

        // Input k
        System.out.print("Enter the value of k: ");
        int k = scanner.nextInt();

        // Find distinct combinations
        List<List<Integer>> combinations = findCombinations(nums, k);

        // Print the distinct combinations
        System.out.println("Distinct combinations of length " + k + ":");
        for (List<Integer> combination : combinations) {
            System.out.println(combination);
        }

	}

}
