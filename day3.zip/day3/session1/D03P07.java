package com.learning.core.day3.session1;

import java.util.*;

class Car implements Comparable<Car> {
    private String name;
    private double price;

    public Car(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return name + " " + price;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Car car = (Car) obj;
        return Double.compare(car.price, price) == 0 && Objects.equals(name, car.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, price);
    }

    @Override
    public int compareTo(Car other) {
        return Double.compare(this.price, other.price);
    }
}

public class D03P07 {
    public static void main(String[] args) {
        TreeMap<Car, String> carMap = new TreeMap<>();

        // Predefined car details
        Car car1 = new Car("Benz", 900000.0);
        Car car2 = new Car("Bugatti", 80050.0);
        Car car3 = new Car("Toyota", 60000.0);
        Car car4 = new Car("Honda", 55000.0);

        carMap.put(car1, car1.getName());
        carMap.put(car2, car2.getName());
        carMap.put(car3, car3.getName());
        carMap.put(car4, car4.getName());

        // Retrieving the key-value mapping associated with the greatest price
        Map.Entry<Car, String> maxEntry = carMap.lastEntry();
        System.out.println(maxEntry.getKey().getName() + " " + maxEntry.getKey().getPrice());

        // Retrieving the key-value mapping associated with the least price
        Map.Entry<Car, String> minEntry = carMap.firstEntry();
        System.out.println(minEntry.getKey().getName() + " " + minEntry.getKey().getPrice());
    }
}