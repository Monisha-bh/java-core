package com.learning.core.day3.session1;
import java.util.HashSet;
import java.util.Iterator;
class Product {
    private String productId;
    private String productName;

    public Product(String productId, String productName) {
        this.productId = productId;
        this.productName = productName;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    @Override
    public int hashCode() {
        return productId.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Product other = (Product) obj;
        return productId.equals(other.productId);
    }

    @Override
    public String toString() {
        return productId + " " + productName;
    }
}
public class D03P04 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		HashSet<Product> products = new HashSet<>();

        // Predefined information of 4 products
        products.add(new Product("P001", "Maruti 800"));
        products.add(new Product("P002", "Maruti Swift"));
        products.add(new Product("P003", "Maruti Dezire"));
        products.add(new Product("P004", "Maruti Alto"));

        // Removing a particular product from the HashSet by using product id
        String productIdToRemove = "P002";
        Product productToRemove = null;
        for (Product product : products) 
        {
            if (product.getProductId().equals(productIdToRemove)) 
            {
                productToRemove = product;
                break;
            }
        }
        if (productToRemove != null) 
        {
            products.remove(productToRemove);
        }

        // Displaying the products after removal
        for (Product product : products)
        {
            System.out.println(product);
        }
    }
	

}
