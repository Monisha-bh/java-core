package com.learning.core.day3.session1;
import java.util.ArrayList;
import java.util.Scanner;
public class D03PO1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ArrayList<String> studentNames = new ArrayList<>();
	        Scanner scanner = new Scanner(System.in);

	        // Adding student names to the ArrayList
	        System.out.println("Enter the names of students (separated by spaces): ");
	        String input = scanner.nextLine();
	        String[] names = input.split(" ");
	        for (String name : names) {
	            studentNames.add(name);
	        }

	        // Finding a particular name
	        System.out.println("Enter the name to search: ");
	        String searchName = scanner.nextLine();

	        if (studentNames.contains(searchName)) {
	            System.out.println("Found in java");
	        } else {
	            System.out.println("Not found in java");
	        }

	}

}
