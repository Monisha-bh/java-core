package com.learning.core.day3.session1;

import java.util.Hashtable;

class Employee {
    private int id;
    private String name;
    private String department;
    private String designation;

    public Employee(int id, String name, String department, String designation) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.designation = designation;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Department: " + department + ", Designation: " + designation;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Employee employee = (Employee) obj;
        return id == employee.id;
    }

    @Override
    public int hashCode() {
        return id;
    }
}

public class D03P09 {
    public static void main(String[] args) {
        Hashtable<Integer, Employee> employeeTable = new Hashtable<>();

        // Predefined employee details
        Employee emp1 = new Employee(101, "John", "HR", "Manager");
        Employee emp2 = new Employee(102, "Alice", "IT", "Developer");
        Employee emp3 = new Employee(103, "Bob", "Finance", "Accountant");
        Employee emp4 = new Employee(104, "Eva", "Marketing", "Marketing Manager");

        employeeTable.put(emp1.getId(), emp1);
        employeeTable.put(emp2.getId(), emp2);
        employeeTable.put(emp3.getId(), emp3);
        employeeTable.put(emp4.getId(), emp4);

        // Verify whether the Hashtable is empty or not
        System.out.println("Is Hashtable empty? " + employeeTable.isEmpty());
    }
}