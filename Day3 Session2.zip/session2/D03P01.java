package com.learning.core.day2.session2;


	class LowBalanceException extends Exception 
	{
	    public LowBalanceException(String message)
	    {
	        super(message);
	    }
	}

	class NegativeAmountException extends Exception 
	{
	    public NegativeAmountException(String message)
	    {
	        super(message);
	    }
	}

	class BankAccount 
	{
	    private int accNo;
	    private String custName;
	    private String accType;
	    private float balance;

	    public BankAccount(int accNo, String custName, String accType, float balance) throws LowBalanceException, NegativeAmountException 
	    {
	        
	        
	        if ((accType.equals("Saving") && balance < 1000) || (accType.equals("Current") && balance < 5000)) 
	        {
	            throw new LowBalanceException("LowBalance");
	        }
	        
	        if (balance < 0)
	        {
	            throw new NegativeAmountException("NegativeAmount");
	        }
	        
	        this.balance = balance;
	    }

	    public void deposit(float amt) throws NegativeAmountException 
	    {
	        if (amt < 0) 
	        {
	            throw new NegativeAmountException("NegativeAmount");
	        }
	        balance += amt;
	        System.out.println("Amount " + amt + " deposited successfully.");
	    }

	    public float getBalance() throws LowBalanceException 
	    {
	        if ((accType.equals("Saving") && balance < 1000) || (accType.equals("Current") && balance < 5000)) 
	        {
	            throw new LowBalanceException("LowBalance");
	        }
	        return balance;
	    }

		

		
	}

	public class D03P01  {
	    public static void main(String[] args) 
	    {
	        try 
	        {
	           // BankAccount account1 = new BankAccount(123, "John", "Saving", 900);
	           // account1.deposit(100);
	          //  System.out.println("Output: " + account1.getBalance());
	            // Uncomment below line to test negative balance exception
	             BankAccount account2 = new BankAccount(123, "John", "Saving", -900);
	             account2.deposit(100); // Uncomment this line to test deposit method
	            System.out.println("Output: " + account2.getBalance());
	        } catch (LowBalanceException e) 
	        {
	            System.out.println("Output: " + e.getMessage());
	        } catch (NegativeAmountException e) 
	        {
	            System.out.println("Output: " + e.getMessage());
	        }
	    }
	}




