package com.learning.core.day1session1;
import java.util.Scanner;
 
public class D01P03_3 {
 
	
 
	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
 
	        // Input marks obtained by the student
	        System.out.println("Enter marks obtained by the student:");
	        double marks = scanner.nextDouble();
 
	        // Calculate percentage
	        double percentage = (marks / 100) * 100;
 
	        // Check grade based on percentage
	        char grade;
	        if (percentage >= 60) {
	            grade = 'A';
	        } else if (percentage >= 45) {
	            grade = 'B';
	        } else if (percentage >= 35) {
	            grade = 'C';
	        } else {
	            grade = 'D';
	        }
 
	        // Output the grade
	        System.out.println("Grade: " + grade);
	    }
}