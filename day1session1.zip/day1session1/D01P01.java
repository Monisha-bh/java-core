package com.learning.core.day1session1;

public class D01P01 {
	 private String bookTitle;
	 private double bookPrice;

	 public String getBookTitle() {
	        return bookTitle;
	    }

	    // Setter for bookTitle
	    public void setBookTitle(String bookTitle) {
	        this.bookTitle = bookTitle;
	    }

	    // Getter for bookPrice
	    public double getBookPrice() {
	        return bookPrice;
	    }

	    // Setter for bookPrice
	    public void setBookPrice(double bookPrice) {
	        this.bookPrice = bookPrice;
	    }
	}

	public class BookManager {
	    // Method to create a Book object
	    public static Book createBook(String title, double price) {
	        Book book = new Book();
	        book.setBookTitle(title);
	        book.setBookPrice(price);
	        return book;
	    }

	    // Method to display Book details
	    public static void showBook(Book book) {
	        System.out.println("Book Title: " + book.getBookTitle() + " and Price: " + book.getBookPrice());
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String title = "Java Programming";
        double price = 350.00;

        // Creating Book object
        Book book = createBook(title, price);

        // Displaying Book details
        showBook(book);

	}

}
