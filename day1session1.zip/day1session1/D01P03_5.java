package com.learning.core.day1session1;
import java.util.Scanner;
public class D01P03_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        // Input number from the user
        System.out.print("Enter a number to find its factorial: ");
        int number = scanner.nextInt();

        // Calculate factorial
        long factorial = calculateFactorial(number);

        // Display the result
        System.out.println("Factorial of " + number + " is " + factorial);
    }

    // Method to calculate factorial recursively
    private static long calculateFactorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        }
        return n * calculateFactorial(n - 1);
	}

}
